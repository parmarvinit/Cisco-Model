# Task 1 model answer
